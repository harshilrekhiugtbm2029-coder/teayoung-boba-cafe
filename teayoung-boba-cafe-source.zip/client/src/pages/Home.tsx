import { useEffect, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  Clock3,
  Coffee,
  Heart,
  Instagram,
  Leaf,
  MapPin,
  Menu as MenuIcon,
  Phone,
  Send,
  Sparkles,
  Star,
  Utensils,
  Wifi,
  X,
} from "lucide-react";

const menuGroups = {
  "Creamy milk boba": [
    { name: "Classic Del Luna", description: "Classic creamy milk boba, best with tapioca pearls", price: "₹140", tag: "classic" },
    { name: "Itaewon Taro", description: "Creamy taro milk boba, best with tapioca pearls", price: "₹160", tag: "taro" },
    { name: "Goblin Matcha", description: "Matcha milk boba, best with tapioca pearls", price: "₹150", tag: "matcha" },
    { name: "Strawberry Sarang", description: "Strawberry milk boba, best with tapioca pearls", price: "₹170", tag: "fruity" },
  ],
  "Iced popping": [
    { name: "Peach Popping", description: "Iced peach drink with peach popping bubbles", price: "₹190", tag: "peach" },
    { name: "Mango Popping", description: "Iced mango drink with mango popping bubbles", price: "₹200", tag: "mango" },
    { name: "Blueberry Popping", description: "Iced blueberry drink with blueberry popping bubbles", price: "₹190", tag: "blueberry" },
    { name: "Mango Blueberry Popping", description: "Mango and blueberry iced drink with popping bubbles", price: "₹190", tag: "mixed" },
  ],
  "Korean ramyun": [
    { name: "Buldak Carbonara", description: "Creamy hot-chicken ramyun with bok choy, boiled egg, vegetables and mushrooms", price: "₹240", tag: "creamy spicy" },
    { name: "2X Spicy", description: "Fiery noodles with sesame, grilled seaweed, bok choy, boiled egg, vegetables and mushrooms", price: "₹240", tag: "extra hot" },
    { name: "Shin Ramyun", description: "Soft chewy noodles in spicy vegetable broth with TeaYoung special chilli oil", price: "₹240", tag: "comfort bowl" },
    { name: "Kimchi Ramyun", description: "Spicy Korean soup noodles with garlic, spices and fried kimchi", price: "₹240", tag: "korean" },
  ],
};

type MenuGroup = keyof typeof menuGroups;

function ScrollReveal({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const node = document.getElementById(`reveal-${Math.random()}`);
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setVisible(true);
        observer.disconnect();
      }
    }, { threshold: 0.14 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div className={`reveal ${visible ? "reveal-visible" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<MenuGroup>("Creamy milk boba");
  const [formSent, setFormSent] = useState(false);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormSent(true);
    event.currentTarget.reset();
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="topline"><span>TeaYoung Boba Tea</span><span>Sector 37 + Sector 75, Noida · open today 11am—10pm</span></div>
      <header className="nav-wrap">
        <a className="wordmark" href="#top" onClick={closeMenu} aria-label="TeaYoung Boba Tea home">
          <img className="brand-logo-image" src="/manus-storage/teayoung-logo-photo_9f322c1a.jpg" alt="Tea Young official wordmark" />
        </a>
        <button className="mobile-toggle" onClick={() => setMenuOpen((value) => !value)} aria-label="Toggle menu" aria-expanded={menuOpen}>
          {menuOpen ? <X size={22} /> : <MenuIcon size={22} />}
        </button>
        <nav className={`main-nav ${menuOpen ? "main-nav-open" : ""}`}>
          <a href="#story" onClick={closeMenu}>Our story</a>
          <a href="#menu" onClick={closeMenu}>Menu</a>
          <a href="#gallery" onClick={closeMenu}>Gallery</a>
          <a href="#visit" onClick={closeMenu}>Find us</a>
          <a href="#contact" onClick={closeMenu}>Say hello</a>
          <a className="nav-cta" href="#menu" onClick={closeMenu}>Get a sip <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-grid-lines" aria-hidden="true"></div>
          <div className="hero-content">
            <div className="eyebrow hero-eyebrow"><span className="eyebrow-dot"></span> Freshly shaken in Noida</div>
            <h1>Good days<br /><em>start here.</em></h1>
            <p className="hero-copy">A little pocket of good energy, bright flavours, and boba worth slowing down for.</p>
            <div className="hero-actions">
              <a className="button button-dark" href="#menu">Explore the menu <ArrowDownRight size={17} /></a>
              <a className="text-link" href="#visit">Come say hi <ChevronRight size={16} /></a>
            </div>
          </div>
          <div className="hero-art" aria-label="A colourful bubble tea cup illustration">
            <div className="sun-disc"></div>
            <div className="hero-sticker sticker-one"><Sparkles size={15} /> made with joy</div>
            <div className="hero-sticker sticker-two">sip<br /><strong>slowly</strong></div>
            <div className="cup-shadow"></div>
            <div className="hero-cup">
              <div className="cup-lid"></div>
              <div className="straw"><span></span></div>
              <div className="cup-body"><div className="tea-swirl"></div><div className="boba-row"><i></i><i></i><i></i><i></i><i></i></div></div>
              <div className="cup-label">TY</div>
            </div>
            <div className="hero-asterisk">✳</div>
          </div>
          <div className="hero-note"><span>01</span><span>not your<br />ordinary<br />tea stop</span></div>
          <a className="scroll-cue" href="#story"><span>Scroll to explore</span><ArrowDownRight size={17} /></a>
        </section>

        <section className="ticker" aria-label="TeaYoung highlights">
          <div className="ticker-track">
            <span>hand-shaken</span><b>✳</b><span>good energy only</span><b>✳</b><span>made to order</span><b>✳</b><span>Sector 37, Noida</span><b>✳</b><span>hand-shaken</span><b>✳</b><span>good energy only</span><b>✳</b><span>made to order</span><b>✳</b><span>Sector 37, Noida</span><b>✳</b>
          </div>
        </section>

        <section id="story" className="story-section section-pad">
          <div className="section-kicker"><span>02</span><span>Our little story</span></div>
          <div className="story-layout">
            <div className="story-heading-wrap">
              <h2>Not just a drink.<br /><em>A small ritual.</em></h2>
              <div className="hand-note"><ArrowDownRight size={18} /><span>take the<br />long way home</span></div>
            </div>
            <div className="story-copy">
              <p className="lead-copy">TeaYoung is the kind of place you find yourself returning to. For the first sip after a long day. For a quick catch-up that stretches into two hours. For a tiny bit of joy, served cold.</p>
              <p>We mix classic tea craft with playful flavours, soft textures, and just enough surprise. Everything is made to order at our little corner in Godavari Complex, Sector 37.</p>
              <a className="underlined-link" href="#visit">Our neighbourhood guide <ArrowUpRight size={15} /></a>
            </div>
          </div>
          <div className="story-collage">
            <div className="collage-card collage-main"><img src="https://images.unsplash.com/photo-1558857563-b371033873b8?auto=format&fit=crop&w=1200&q=85" alt="A colourful drink on a café table" /><span className="image-caption">small joys, served daily</span></div>
            <div className="collage-card collage-side"><img src="https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=900&q=85" alt="Tea being poured into a glass" /><span className="image-caption">steeped with care</span></div>
            <div className="collage-quote"><Heart size={20} fill="currentColor" /><span>Come as you are.<br /><em>Leave a little lighter.</em></span></div>
          </div>
        </section>

        <section id="menu" className="menu-section section-pad">
          <div className="section-kicker light"><span>03</span><span>What we're pouring</span></div>
          <div className="menu-heading-row"><h2>Pick your<br /><em>mood.</em></h2><p>From first dates to last-minute plans, there is a little something for every kind of day.</p></div>
          <div className="menu-tabs" role="tablist" aria-label="Menu categories">
            {(Object.keys(menuGroups) as MenuGroup[]).map((group) => <button key={group} className={activeMenu === group ? "active" : ""} onClick={() => setActiveMenu(group)} role="tab" aria-selected={activeMenu === group}>{group}</button>)}
          </div>
          <div className="menu-list">
            {menuGroups[activeMenu].map((item, index) => <article className="menu-item" key={item.name} style={{ animationDelay: `${index * 70}ms` }}><div className="menu-index">0{index + 1}</div><div className="menu-item-copy"><h3>{item.name} <span>{item.tag}</span></h3><p>{item.description}</p></div><div className="menu-price">{item.price}</div></article>)}
          </div>
          <div className="menu-footer"><span><Leaf size={16} /> vegetarian-friendly options</span><span>Tapioca pearls ₹20 · popping bubbles ₹30</span><a href="#contact">Ask us anything <ArrowUpRight size={15} /></a></div>
        </section>

        <section className="experience-section section-pad">
          <div className="experience-card experience-photo"><img src="https://images.unsplash.com/photo-1522992319-0365e5f11656?auto=format&fit=crop&w=1200&q=85" alt="Friends enjoying drinks at a café" /><div className="photo-overlay"></div><div className="photo-label"><span>the vibe</span><strong>come for the tea.<br />stay for the feeling.</strong></div></div>
          <div className="experience-card experience-copy"><div className="eyebrow"><span className="eyebrow-dot coral"></span> More than a pit stop</div><h2>There is always<br /><em>room for one more.</em></h2><p>Drop in solo with your headphones, bring the whole gang, or make it your new study spot. Free Wi-Fi, comfortable corners, and a playlist that knows the assignment.</p><div className="experience-perks"><span><Wifi size={18} /> free wi-fi</span><span><Coffee size={18} /> fresh brews</span><span><Utensils size={18} /> little bites</span></div><a className="button button-coral" href="#visit">Plan your visit <ArrowUpRight size={16} /></a></div>
        </section>

        <section id="gallery" className="gallery-section section-pad">
          <div className="section-kicker"><span>04</span><span>Little moments</span></div>
          <div className="gallery-heading-row"><h2>See you<br /><em>inside.</em></h2><p>Real TeaYoung drinks, colourful counters, and the neighbourhood energy behind every order.</p></div>
          <div className="gallery-grid">
            <figure className="gallery-tile gallery-tile-tall"><img src="/manus-storage/cafe-02_fdee81e8.jpg" alt="TeaYoung Boba Tea counter and storefront interior" /><figcaption>the TeaYoung counter</figcaption></figure>
            <figure className="gallery-tile"><img src="/manus-storage/cafe-01_46c7c251.jpg" alt="TeaYoung branded boba drink inside the café" /><figcaption>made to order</figcaption></figure>
            <figure className="gallery-tile gallery-tile-accent"><div className="gallery-accent-mark">✳</div><figcaption>good energy<br /><em>in every corner</em></figcaption></figure>
            <figure className="gallery-tile gallery-tile-wide"><img src="/manus-storage/menu-02_de7883a7.jpg" alt="TeaYoung creamy milk boba and iced popping drinks menu" /><figcaption>our drinks menu</figcaption></figure>
            <figure className="gallery-tile"><img src="/manus-storage/cafe-03_5e5ac257.jpg" alt="TeaYoung branded iced fruit drink" /><figcaption>bright sips</figcaption></figure>
          </div>
        </section>

        <section id="visit" className="visit-section section-pad">
          <div className="visit-intro"><div className="section-kicker"><span>05</span><span>Come find us</span></div><h2>Two Noida<br /><em>neighbourhoods.</em></h2><p>Pick the TeaYoung closest to you and drop in for a fresh drink.</p></div>
          <div className="visit-details locations-grid"><div className="detail-block"><MapPin size={21} /><div><span className="detail-label">Sector 37</span><p>Shop K-4, Godavari Complex<br />Arun Vihar, Sector 37<br />Noida, Uttar Pradesh</p><a href="https://www.google.com/maps/search/?api=1&query=Teayoung+Boba+Tea+Sector+37+Noida" target="_blank" rel="noreferrer">Open in maps <ArrowUpRight size={14} /></a></div></div><div className="detail-block"><MapPin size={21} /><div><span className="detail-label">Sector 75</span><p>Shop no 17, Golf Avenue<br />Behind Spectrum Mall, Sector 75<br />Noida, Uttar Pradesh 201316</p><a href="https://www.google.com/maps/search/?api=1&query=Shop+17+Golf+Avenue+behind+Spectrum+Mall+Sector+75+Noida+201316" target="_blank" rel="noreferrer">Open in maps <ArrowUpRight size={14} /></a></div></div><div className="detail-block"><Clock3 size={21} /><div><span className="detail-label">Hours</span><p>Monday — Sunday<br /><strong>11:00 am — 10:00 pm</strong></p><span className="status-pill"><i></i> Open daily</span></div></div><div className="detail-block"><Instagram size={21} /><div><span className="detail-label">Follow along</span><p>@teayoungbobacafe<br />for new drops & good news</p><a href="https://www.instagram.com/teayoungbobacafe/?hl=en" target="_blank" rel="noreferrer">See Instagram <ArrowUpRight size={14} /></a></div></div></div>
          <div className="map-card"><div className="map-surface"><div className="map-grid"></div><div className="map-road road-one"></div><div className="map-road road-two"></div><div className="map-pin map-pin-one"><MapPin size={22} fill="currentColor" /><span>Sector 37</span></div><div className="map-pin map-pin-two"><MapPin size={22} fill="currentColor" /><span>Sector 75</span></div><span className="map-label map-label-one">Arun Vihar</span><span className="map-label map-label-two">Golf Avenue</span><span className="map-label map-label-three">Two TeaYoung locations in Noida</span></div><a className="map-link" href="https://www.google.com/maps/search/?api=1&query=TeaYoung+Boba+Tea+Noida" target="_blank" rel="noreferrer">View both locations <ArrowUpRight size={15} /></a></div>
        </section>

        <section id="contact" className="contact-section section-pad"><div className="contact-card"><div className="contact-copy"><div className="eyebrow"><span className="eyebrow-dot"></span> Say hello</div><h2>Have a question?<br /><em>We'd love to hear it.</em></h2><p>Planning a small celebration, have a menu question, or just want to say hi? Call or message TeaYoung directly.</p><div className="contact-meta"><a href="tel:+918851372876"><Phone size={16} /> +91 88513 72876</a><a href="https://wa.me/918851372876" target="_blank" rel="noreferrer"><Send size={16} /> Message on WhatsApp</a></div></div><form className="contact-form" onSubmit={handleSubmit}>{formSent ? <div className="form-success"><span><Check size={20} /></span><h3>Message ready.</h3><p>For the fastest response, send your question to TeaYoung on WhatsApp.</p><a className="button button-dark" href="https://wa.me/918851372876" target="_blank" rel="noreferrer">Open WhatsApp <ArrowUpRight size={16} /></a></div> : <><label>Your name<input name="name" placeholder="How should we call you?" required /></label><label>Phone or email<input name="contact" placeholder="Your preferred contact" required /></label><label>What is on your mind?<textarea name="message" rows={3} placeholder="Tell us everything..." required /></label><button className="button button-dark form-submit" type="submit">Continue <ArrowUpRight size={16} /></button></>}</form></div></section>
      </main>

      <footer className="footer"><div className="footer-top"><a className="wordmark footer-wordmark" href="#top"><img className="brand-logo-image" src="/manus-storage/teayoung-logo-photo_9f322c1a.jpg" alt="Tea Young official wordmark" /></a><p>A tiny tea stop<br />with a big heart.</p><div className="footer-links"><a href="#story">Our story</a><a href="#menu">Menu</a><a href="#gallery">Gallery</a><a href="#visit">Find us</a><a href="https://www.instagram.com/teayoungbobacafe/?hl=en" target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={13} /></a></div></div><div className="footer-bottom"><span>© 2026 TeaYoung Boba Tea</span><span>Made for good days.</span><span className="footer-note">Business information and images used with owner approval.</span></div></footer>
    </div>
  );
}

// Keep React's JSX namespace available to the TSX compiler without adding another dependency.
void ScrollReveal;
