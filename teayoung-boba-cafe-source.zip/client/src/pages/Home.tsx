import { useEffect, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  Clock3,
  Coffee,
  Heart,
  Instagram,
  Leaf,
  MapPin,
  Menu as MenuIcon,
  Phone,
  Send,
  Sparkles,
  Star,
  Utensils,
  Wifi,
  X,
} from "lucide-react";

const menuGroups = {
  "Boba classics": [
    { name: "Brown Sugar Cloud", description: "Slow-steeped tea, brown sugar pearls, silky milk", price: "₹220", tag: "bestseller" },
    { name: "Taro Cream Tea", description: "Velvety taro, jasmine tea, a cloud of cream", price: "₹210", tag: "soft & creamy" },
    { name: "Mango Pop", description: "Bright mango, green tea, popping boba", price: "₹190", tag: "fresh" },
  ],
  "Tea & coffee": [
    { name: "Matcha Cloud Latte", description: "Ceremonial matcha, oat milk, vanilla sea salt", price: "₹240", tag: "new" },
    { name: "Rose Milk Tea", description: "Black tea, rose, milk, strawberry jelly", price: "₹200", tag: "floral" },
    { name: "Cold Brew Float", description: "Small-batch cold brew, vanilla cream, cacao nibs", price: "₹230", tag: "café pick" },
  ],
  "Little bites": [
    { name: "Cinnamon Waffle", description: "Warm waffle, cinnamon sugar, whipped cream", price: "₹180", tag: "shareable" },
    { name: "Crispy Corn Bites", description: "Golden sweetcorn, chilli lime, house dip", price: "₹160", tag: "snack time" },
    { name: "Mochi Trio", description: "Three soft mochi, rotating seasonal flavours", price: "₹150", tag: "sweet" },
  ],
};

type MenuGroup = keyof typeof menuGroups;

function ScrollReveal({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const node = document.getElementById(`reveal-${Math.random()}`);
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setVisible(true);
        observer.disconnect();
      }
    }, { threshold: 0.14 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div className={`reveal ${visible ? "reveal-visible" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<MenuGroup>("Boba classics");
  const [formSent, setFormSent] = useState(false);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormSent(true);
    event.currentTarget.reset();
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="topline"><span>TeaYoung Boba Tea</span><span>Sector 37, Noida · open today 11am—10pm</span></div>
      <header className="nav-wrap">
        <a className="wordmark" href="#top" onClick={closeMenu} aria-label="TeaYoung Boba Tea home">
          <span className="wordmark-mark"><span></span><span></span><span></span></span>
          <span>teayoung</span>
        </a>
        <button className="mobile-toggle" onClick={() => setMenuOpen((value) => !value)} aria-label="Toggle menu" aria-expanded={menuOpen}>
          {menuOpen ? <X size={22} /> : <MenuIcon size={22} />}
        </button>
        <nav className={`main-nav ${menuOpen ? "main-nav-open" : ""}`}>
          <a href="#story" onClick={closeMenu}>Our story</a>
          <a href="#menu" onClick={closeMenu}>Menu</a>
          <a href="#visit" onClick={closeMenu}>Find us</a>
          <a href="#contact" onClick={closeMenu}>Say hello</a>
          <a className="nav-cta" href="#menu" onClick={closeMenu}>Get a sip <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-grid-lines" aria-hidden="true"></div>
          <div className="hero-content">
            <div className="eyebrow hero-eyebrow"><span className="eyebrow-dot"></span> Freshly shaken in Noida</div>
            <h1>Good days<br /><em>start here.</em></h1>
            <p className="hero-copy">A little pocket of good energy, bright flavours, and boba worth slowing down for.</p>
            <div className="hero-actions">
              <a className="button button-dark" href="#menu">Explore the menu <ArrowDownRight size={17} /></a>
              <a className="text-link" href="#visit">Come say hi <ChevronRight size={16} /></a>
            </div>
          </div>
          <div className="hero-art" aria-label="A colourful bubble tea cup illustration">
            <div className="sun-disc"></div>
            <div className="hero-sticker sticker-one"><Sparkles size={15} /> made with joy</div>
            <div className="hero-sticker sticker-two">sip<br /><strong>slowly</strong></div>
            <div className="cup-shadow"></div>
            <div className="hero-cup">
              <div className="cup-lid"></div>
              <div className="straw"><span></span></div>
              <div className="cup-body"><div className="tea-swirl"></div><div className="boba-row"><i></i><i></i><i></i><i></i><i></i></div></div>
              <div className="cup-label">TY</div>
            </div>
            <div className="hero-asterisk">✳</div>
          </div>
          <div className="hero-note"><span>01</span><span>not your<br />ordinary<br />tea stop</span></div>
          <a className="scroll-cue" href="#story"><span>Scroll to explore</span><ArrowDownRight size={17} /></a>
        </section>

        <section className="ticker" aria-label="TeaYoung highlights">
          <div className="ticker-track">
            <span>hand-shaken</span><b>✳</b><span>good energy only</span><b>✳</b><span>made to order</span><b>✳</b><span>Sector 37, Noida</span><b>✳</b><span>hand-shaken</span><b>✳</b><span>good energy only</span><b>✳</b><span>made to order</span><b>✳</b><span>Sector 37, Noida</span><b>✳</b>
          </div>
        </section>

        <section id="story" className="story-section section-pad">
          <div className="section-kicker"><span>02</span><span>Our little story</span></div>
          <div className="story-layout">
            <div className="story-heading-wrap">
              <h2>Not just a drink.<br /><em>A small ritual.</em></h2>
              <div className="hand-note"><ArrowDownRight size={18} /><span>take the<br />long way home</span></div>
            </div>
            <div className="story-copy">
              <p className="lead-copy">TeaYoung is the kind of place you find yourself returning to. For the first sip after a long day. For a quick catch-up that stretches into two hours. For a tiny bit of joy, served cold.</p>
              <p>We mix classic tea craft with playful flavours, soft textures, and just enough surprise. Everything is made to order at our little corner in Godavari Complex, Sector 37.</p>
              <a className="underlined-link" href="#visit">Our neighbourhood guide <ArrowUpRight size={15} /></a>
            </div>
          </div>
          <div className="story-collage">
            <div className="collage-card collage-main"><img src="https://images.unsplash.com/photo-1558857563-b371033873b8?auto=format&fit=crop&w=1200&q=85" alt="A colourful drink on a café table" /><span className="image-caption">small joys, served daily</span></div>
            <div className="collage-card collage-side"><img src="https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=900&q=85" alt="Tea being poured into a glass" /><span className="image-caption">steeped with care</span></div>
            <div className="collage-quote"><Heart size={20} fill="currentColor" /><span>Come as you are.<br /><em>Leave a little lighter.</em></span></div>
          </div>
        </section>

        <section id="menu" className="menu-section section-pad">
          <div className="section-kicker light"><span>03</span><span>What we're pouring</span></div>
          <div className="menu-heading-row"><h2>Pick your<br /><em>mood.</em></h2><p>From first dates to last-minute plans, there is a little something for every kind of day.</p></div>
          <div className="menu-tabs" role="tablist" aria-label="Menu categories">
            {(Object.keys(menuGroups) as MenuGroup[]).map((group) => <button key={group} className={activeMenu === group ? "active" : ""} onClick={() => setActiveMenu(group)} role="tab" aria-selected={activeMenu === group}>{group}</button>)}
          </div>
          <div className="menu-list">
            {menuGroups[activeMenu].map((item, index) => <article className="menu-item" key={item.name} style={{ animationDelay: `${index * 70}ms` }}><div className="menu-index">0{index + 1}</div><div className="menu-item-copy"><h3>{item.name} <span>{item.tag}</span></h3><p>{item.description}</p></div><div className="menu-price">{item.price}</div></article>)}
          </div>
          <div className="menu-footer"><span><Leaf size={16} /> vegetarian-friendly options</span><span>Menu changes with the season</span><a href="#contact">Ask us anything <ArrowUpRight size={15} /></a></div>
        </section>

        <section className="experience-section section-pad">
          <div className="experience-card experience-photo"><img src="https://images.unsplash.com/photo-1522992319-0365e5f11656?auto=format&fit=crop&w=1200&q=85" alt="Friends enjoying drinks at a café" /><div className="photo-overlay"></div><div className="photo-label"><span>the vibe</span><strong>come for the tea.<br />stay for the feeling.</strong></div></div>
          <div className="experience-card experience-copy"><div className="eyebrow"><span className="eyebrow-dot coral"></span> More than a pit stop</div><h2>There is always<br /><em>room for one more.</em></h2><p>Drop in solo with your headphones, bring the whole gang, or make it your new study spot. Free Wi-Fi, comfortable corners, and a playlist that knows the assignment.</p><div className="experience-perks"><span><Wifi size={18} /> free wi-fi</span><span><Coffee size={18} /> fresh brews</span><span><Utensils size={18} /> little bites</span></div><a className="button button-coral" href="#visit">Plan your visit <ArrowUpRight size={16} /></a></div>
        </section>

        <section id="visit" className="visit-section section-pad">
          <div className="visit-intro"><div className="section-kicker"><span>04</span><span>Come find us</span></div><h2>Your next<br /><em>favourite corner.</em></h2><p>We are tucked inside Godavari Complex, ready when you are.</p></div>
          <div className="visit-details"><div className="detail-block"><MapPin size={21} /><div><span className="detail-label">Address</span><p>Shop K-4, Godavari Complex<br />Arun Vihar, Sector 37<br />Noida, Uttar Pradesh</p><a href="https://www.google.com/maps/search/?api=1&query=Teayoung+Boba+Tea+Sector+37+Noida" target="_blank" rel="noreferrer">Open in maps <ArrowUpRight size={14} /></a></div></div><div className="detail-block"><Clock3 size={21} /><div><span className="detail-label">Hours</span><p>Monday — Sunday<br /><strong>11:00 am — 10:00 pm</strong></p><span className="status-pill"><i></i> Usually open now</span></div></div><div className="detail-block"><Instagram size={21} /><div><span className="detail-label">Follow along</span><p>@teayoungbobacafe<br />for new drops & good news</p><a href="https://www.instagram.com/teayoungbobacafe/?hl=en" target="_blank" rel="noreferrer">See Instagram <ArrowUpRight size={14} /></a></div></div></div>
          <div className="map-card"><div className="map-surface"><div className="map-grid"></div><div className="map-road road-one"></div><div className="map-road road-two"></div><div className="map-pin"><MapPin size={22} fill="currentColor" /><span>TeaYoung</span></div><span className="map-label map-label-one">Arun Vihar</span><span className="map-label map-label-two">Sector 37</span><span className="map-label map-label-three">Godavari Complex</span></div><a className="map-link" href="https://www.google.com/maps/search/?api=1&query=Teayoung+Boba+Tea+Sector+37+Noida" target="_blank" rel="noreferrer">Get directions <ArrowUpRight size={15} /></a></div>
        </section>

        <section id="contact" className="contact-section section-pad"><div className="contact-card"><div className="contact-copy"><div className="eyebrow"><span className="eyebrow-dot"></span> Say hello</div><h2>Have a question?<br /><em>We'd love to hear it.</em></h2><p>Planning a small celebration, have a menu question, or just want to say hi? Send us a note and we will get back to you.</p><div className="contact-meta"><a href="tel:+919999999999"><Phone size={16} /> +91 99999 99999</a><a href="mailto:hello@teayoung.in"><Send size={16} /> hello@teayoung.in</a></div></div><form className="contact-form" onSubmit={handleSubmit}>{formSent ? <div className="form-success"><span><Check size={20} /></span><h3>Message received.</h3><p>Thanks for reaching out — we will be in touch soon.</p><button type="button" className="text-link" onClick={() => setFormSent(false)}>Send another note <ArrowUpRight size={15} /></button></div> : <><label>Your name<input name="name" placeholder="How should we call you?" required /></label><label>Email address<input type="email" name="email" placeholder="you@example.com" required /></label><label>What is on your mind?<textarea name="message" rows={3} placeholder="Tell us everything..." required /></label><button className="button button-dark form-submit" type="submit">Send it our way <ArrowUpRight size={16} /></button></>}</form></div></section>
      </main>

      <footer className="footer"><div className="footer-top"><a className="wordmark footer-wordmark" href="#top"><span className="wordmark-mark"><span></span><span></span><span></span></span><span>teayoung</span></a><p>A tiny tea stop<br />with a big heart.</p><div className="footer-links"><a href="#story">Our story</a><a href="#menu">Menu</a><a href="#visit">Find us</a><a href="https://www.instagram.com/teayoungbobacafe/?hl=en" target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={13} /></a></div></div><div className="footer-bottom"><span>© 2026 TeaYoung Boba Tea</span><span>Made for good days.</span><span className="footer-note">Concept website — menu & contact details to be confirmed with the owner.</span></div></footer>
    </div>
  );
}

// Keep React's JSX namespace available to the TSX compiler without adding another dependency.
void ScrollReveal;
